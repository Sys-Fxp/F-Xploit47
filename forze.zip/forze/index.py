import os, sys, hashlib
from time import sleep
try:
	import inquirer
except ModuleNotFoundError:
	exit("* 'inquirer' not installed")
clear = lambda: os.system("cls") if "cmd" in sys.platform.lower() else os.system("clear")
run = lambda call: os.system(call)
logo = """
\x1b[1;91m     ▄▄▀▀▀▀▀▀▀▀▀▄▄
\x1b[1;91m    █             █	   \x1b[1;97m _____                 _____     _
\x1b[1;91m   █          \x1b[1;92m▄▄▄ \x1b[1;91m █       \x1b[1;97m|   __|___ ___ ___ ___| __  |___| |_
\x1b[1;91m   █  \x1b[1;92m▄▄▄ \x1b[1;93m ▄  \x1b[1;92m███ \x1b[1;91m █       \x1b[1;97m|   __| . |  _|- _| -_| __ -| . |  _|
\x1b[1;91m   ▄█ \x1b[1;93m▄   ▀▀▀   ▄ \x1b[1;91m█▄       \x1b[1;97m|__|  |___|_| |___|___|_____|___|_|
\x1b[1;91m   █  \x1b[1;93m▀█▀█▀█▀█▀█▀  \x1b[1;91m█	   \x1b[41m\x1b[1;97m        Author By: Mr.Crifty        \x1b[0m
\x1b[1;91m   ▄██▄▄\x1b[1;93m▀▀▀▀▀▀▀\x1b[1;91m▄▄██▄
\x1b[1;91m ▄█ █▀▀█▀▀▀█▀▀▀█▀▀█ █▄

"""

def imported_inqs(array, choose):
	data, num = {}, 0
	for arr in array:
		num += 1
		data.update({arr: str(num)})
	soups = data[str(choose)]
	return soups

def menu_choice(menu):
	quest = [
		inquirer.List("choose",
			message="Choose menu tools",
			choices=menu,
        	),
	]
	answer = inquirer.prompt(quest)
	try:
		yosh = imported_inqs(menu, answer["choose"])
	except TypeError:
		exit("Cancel call response")
	return int(yosh)

def write(teks):
	for c in teks + "\n":
		sys.stdout.write(c)
		sys.stdout.flush()
		sleep(0000.002)

def start_menu():
	clear()
	write(logo)
	menu = [
		"Grabber domain", #1
		"Scanner tools", #2
		"Auto upload file to shell", #3
		"Reverse and subdo scanner (domain)", #4
		"visitor site (jinglink)", #5
		"index of open dir + dumping", #6
		"Mass scan Wordpress", #7
		"Dorker + mass scan (SQLI + LFI + SPECIFIC SITE)", #8
		"reverse domain/ip V1", #9
		"reverse ip/domain V2", #10
		"Remove duplikat content", #11
		"Wordpress bruteforce", #12
		"Wordpress install", #13
		"Rfm Checker", #14
		"Ip grabber Auto Compile", #15
		"Phpdebugbar auto exploit", #16
		"Exit Program",
	]
	pil = menu_choice(menu)
	if pil == 1:
		oke = menu_choice(["Grabber domain v1", "Grabber domain v2", "Grabber domain v3", "Back main menu"])
		if oke == 1:
			name = "tools/dom.py"
		elif oke == 2:
			name = "tools/grabber.py"
		elif oke == 3:
			name = "tools/grabv3.py"
		elif oke == 4:
			start_menu()
		try:
			run("python "+name)
			exit("\x1b[1;93m[\x1b[1;91m-\x1b[1;93m]\x1b[1;97m Program end, see you \n")
		except Exception as ex:
			exit("\x1b[1;93m[\x1b[1;91m-\x1b[1;93m] \x1b[1;91mError\x1b[1;97m: "+str(ex))
	elif pil == 2:
		oke = menu_choice(["scanner laravel target + multi", "Web Shell Scanner", "Laravel Environment Scanner + PHPUnit Rce", "Back main menu"])
		if oke == 1:
			name = "tools/laravel.py"
		elif oke == 2:
			name = "tools/scanshell.py"
		elif oke == 3:
			name = "tools/laravel2.py"
		elif oke == 4:
			start_menu()
		try:
			run("python "+name)
			exit("\x1b[1;93m[\x1b[1;91m-\x1b[1;93m]\x1b[1;97m Program end, see you \n")
		except Exception as ex:
			exit("\x1b[1;93m[\x1b[1;91m-\x1b[1;93m] \x1b[1;91mError\x1b[1;97m: "+str(ex))
	elif pil == 3:
		name = "tools/upshell.py"
	elif pil == 4:
		name = "tools/revip.py"
	elif pil == 5:
		name = "tools/visit.py"
	elif pil == 6:
		name = "tools/scan.py"
	elif pil == 7:
		name = "tools/scan-wp.py crifty3.txt"
	elif pil == 8:
		name = "tools/dorker.py"
	elif pil == 9:
		name = "tools/reperse.py"
	elif pil == 10:
		name = "tools/revs.py"
	elif pil == 11:
		name = "tools/duplicat.py"
	elif pil == 12:
		name = "tools/wpbf.py"
	elif pil == 13:
		name = "tools/wpins.py"
	elif pil == 14:
		name = "tools/filem.py"
	elif pil == 15:
		name = "tools/ip-generator.py"
	elif pil == 16:
		name = "tools/debugbar.py"
	elif pil == 17:
		exit("\x1b[1;93m[\x1b[1;91m-\x1b[1;93m]\x1b[1;97m Program end, see you \n")
	try:
		run("python "+name)
		exit("\x1b[1;93m[\x1b[1;91m-\x1b[1;93m]\x1b[1;97m Program end, see you \n")
	except Exception as ex:
		exit("\x1b[1;93m[\x1b[1;91m-\x1b[1;93m] \x1b[1;91mError\x1b[1;97m: "+str(ex))


#-> setup setting shortcut
def setup(keys="[['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]"):
	try:
		print("\x1b[1;93m[\x1b[1;92m!\x1b[1;93m]\x1b[1;97m Setup installing tools")
		keys = f"extra-keys = {keys}"
		try:
			os.mkdir('/data/data/com.termux/files/home/.termux')
		except:
			pass
		path = '/data/data/com.termux/files/home/.termux/termux.properties'
		if "DOWN" in open(path, "r").read():
			pass
		else:
			open(path, "w").write(keys)
			os.system('termux-reload-settings')
		print("\x1b[1;93m[\x1b[1;92m!\x1b[1;93m]\x1b[1;97m Done...")
	except:
		pass

def login(key="08a5816ec574ddbbeb7f66cf11ce5c3e"):
	clear()
	print(logo)

	#-> input password
	quest = inquirer.prompt([inquirer.Password("pass", message="Password tools")]).get("pass")
	enc = hashlib.md5(quest.encode("utf")).hexdigest()
	if key == enc:
		print("\x1b[1;93m[\x1b[1;92m✓\x1b[1;93m]\x1b[1;97m Login successfully")
		sleep(00.2)
		start_menu()
	else:
		print("\x1b[1;93m[\x1b[1;91m!\x1b[1;93m]\x1b[1;97m Login failed"); sleep(0.4); login()


if __name__=="__main__":
	setup()
	login()
