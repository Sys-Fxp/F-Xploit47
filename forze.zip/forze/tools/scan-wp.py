import requests
import sys

try:
    with open(sys.argv[1], 'r') as f:
        domains = f.readlines()
except:
    print('[!] File tidak ditemukan')
    sys.exit(1)
try:
    with open('wordpress.txt', 'w') as f:
        pass
except:
    print('[!] Gagal membuat file output')
    sys.exit(1)
for domain in domains:
    domain = domain.strip()
    url = 'http://' + domain + '/wp-login.php'
    try:
        r = requests.get(url)
        if r.status_code == 200:
            with open('wordpress.txt', 'a') as f:
                f.write(domain + '\n')
            print('-> Ini wordpress tuan : ' + url)
        else:
            print('-> Bukan wordpress : ' + url)
    except:
        print('-> Gagal mengakses : ' + url)