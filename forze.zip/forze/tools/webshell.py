import requests as r, os
from multiprocessing import Process


def checker(url):
	try:
		cek = r.get(url)
		if cek.status_code == 200 and "shell" in str(cek.text) or "Shell" in str(cek.text).lower():
			open("live-chek.txt", "a+").write(url+"\n")
			print("\r  \x1b[1;92m> LIVE: "+url+"\x1b[1;00m")
		else:
			print("\r  \x1b[1;91m> DIEE: "+url+"\x1b[1;00m")
	except:
		print("\r  \x1b[1;91m> DIEE: "+url+"\x1b[1;00m")

def main():
	os.system("clear")
	print("\n\n\t[ WEBSHELL CHECKER ]\n\n")
	print("\n\n\t[ Author : Mr.Crifty | Forze XPLOIT ]\n\n")
	nx = input("[*] File: ")
	try:
		oh = open(nx, "r").read().strip().split("\n")
	except FileNotFoundError:
		exit("[×] Files not found\n")
	print("[+] Save result: live-chek.txt")
	print("-"*30)
	for _ in oh:
		th = Process(target=checker, args=(_,))
		th.start()

if __name__=="__main__":
	main()
