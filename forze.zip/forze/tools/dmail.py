from random import choice
from os import system
from re import search
try:
	from faker import Faker
except ModuleNotFoundError:
	system("pip install faker")

system('clear')
fake = Faker("en")
dump = input("[>] Mau berapa email?: ")
while dump == "" or not dump.isdigit():
	dump = input("[>] Mau berapa email?: ")
for x in range(1, int(dump)):
	strings = choice([
		fake.name().split(" ")[0]+fake.name().split(" ")[1],
		fake.name().split(" ")[0]+fake.name().split(" ")[1]+fake.time().replace(":",""),
		fake.name().split(" ")[0]+fake.name().split(" ")[1]+fake.date().split("-")[1]+fake.date().split("-")[2],
		search("(.*?)@.*?", fake.email()).group(1)
	])
	mailist = choice(["@hotmail.com","@yahoo.co.id","@yahoo.com","@gmail.com","@aol.com","@mail.firstfruit.com","@yandex.com","@yandex.ru"])
	results = strings.lower()+mailist
	with open("email_dumps.txt","a+") as sv:
		try:
			if results not in open("email_dumps.txt","r").read():
				sv.write(results+"\n")
		except:
			sv.write(results+"\n")
	print("\r[>] Grabbed - "+str(x)+" - email ", end="")
print("\n[✓] Done, save: email_dumps.txt")
