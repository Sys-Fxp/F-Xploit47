import os
from concurrent.futures import ThreadPoolExecutor as work
saved = "crifty_duplikat.txt"
writer = 0

def write(name, content):
	global writer
	try:
		if content in str(open(name, "r").read()):
			pass
		else:
			open(name, "a+").write(content.replace("\n","")+"\n")
	except:
		open(name, "a+").write(content.replace("\n","")+"\n")
	writer += 1
	print("\r[*] "+str(writer)+" content removed ", end="")

def openFile():
	while True:
		inputFile = input("[=] Enter the domain list file: ")
		try:
			openF = open(inputFile, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("[×] File does not exist")
			continue
		break
	print("[=] Result save as: "+saved)
	with work(max_workers=5) as sub:
		for ars in openF:
			sub.submit(write, saved, ars)
	exit("\r[✓] Proses is done")

if __name__=="__main__":
	os.system("clear"); print("\n\n")
	openFile()
