import requests as r, random, os
from bs4 import BeautifulSoup as par
from concurrent.futures import ThreadPoolExecutor as pol
save = "ipgenerate-vuln.txt"

def ip_generat(max_ip=255):
	result = []
	for x in range(4):
		rand = random.randint(x, max_ip)
		result.append(str(rand))
	return ".".join(result)

def runner(ips):
	global save
	for ipTar in ips:
		cek = par(r.post("https://askdns.com/search", data={"domip": ipTar}, headers={"user-agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"}, allow_redirects=True).text, "html.parser")
		if "None Found" in str(cek):
			print("\t [•] ("+ipTar+") No found result")
			break
		else:
			flex = cek.findAll("div", {"class":"flex two"})[-1]
			tangkap, gets = [], 0
			for yup in flex.find_all("a"):
				gets += 1
				if "Click Here" in str(yup.text):
					gets -= 1
					break
				else:
					with open(save, "a+") as sub:
						sub.write(yup.text+"\n")
					tangkap.append(yup.text)
			if gets != 0:
				print("\t [•] Success Get "+str(gets)+" result from "+ipTar)
			else:
				print("\t [•] ("+ipTar+") No found result")

def main():
	print("\t--// IP GENERATOR > IP TO DOMAIN")
	count = input("\n>> Total ip: ")
	while not count.isdigit():
		count = input(">> Total ip: ")

	tangkap = []
	for x in range(int(count)):
		ok = ip_generat()
		if ok in tangkap:
			pass
		else:
			print("\r>> get ip "+str(len(tangkap))+" ", end="")
			tangkap.append(ok)
	print("\r>> Please wait..\n")

	with pol(max_workers=20) as sub:
		sub.submit(runner, tangkap)
	print("\n>> Done.. Save to ("+save+")")


if __name__=="__main__":
	os.system("clear")
	main()
