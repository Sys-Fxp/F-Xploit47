try:
	import requests as r, os, platform, re
	from bs4 import BeautifulSoup as par
	from time import sleep
	from concurrent.futures import ThreadPoolExecutor as wok
	from random import choice
except Exception as err:
	exit("!!: "+str(err))

clear = lambda: os.system("clear") if platform.system().lower() == "linux" else os.system("cls")
openFile = lambda file: open(file, "r").read().strip().split("\n")
agent = r.get("https://raw.githubusercontent.com/capture0x/XSHOCK/master/useragent.txt").text.strip().split("\n")

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")

def saved():
	while True:
		fln = input("?: save in file: ")
		try:
			openFile(fln)
			ask = input("!: File ini sudah ada\n?: apakah hasilnya mau digabung dengan file ini?\n  >> ya/tidak (Y/T): ")
			if ask in list("Yy"):
				break
			elif ask in list("Tt"):
				continue
			else:
				continue
		except FileNotFoundError:
			break
	return fln

def ceks():
	fileip = input("?: File list url: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("!: File not found")
			fileip = input("?: File list url: ")
			continue
		break
	return check

def menunggu():
	try:
		for y in range(20):
			try:
				for x in list("-\|/"):
					print("\r   "+x+": jangan buru buru-lah masbro ("+str(y+1)+"/20) ", end="")
					sleep(0.3)
			except KeyboardInterrupt:
				break
	except KeyboardInterrupt:
		pass


def subdomain(subdo, file):
	subdo = subdo.replace("http://","").replace("https://","").split("/")[0]
	cek = r.get("https://apiwhats.my.id/subdomain?subdo="+subdo)
	try:
		for x in cek.json()["result"]:
			writer(file, "http://%s" % (x))
		print("  [URL] \x1b[1;95m"+subdo+"\x1b[1;00m -> \x1b[1;92m"+str(len(cek.json()["result"]))+"\x1b[1;00m subdomain found! ")
	except:
		writer(file, "http://%s" % (subdo))
		print("  [URL] \x1b[1;95m"+subdo+"\x1b[1;00m ->\x1b[1;91m "+file+"\x1b[1;00m, domain not found!")

def revold(rev, file):
	rev = rev.replace("http://","").replace("https://","").split("/")[0]
	cek = r.get("https://apiwhats.my.id/reverse?rev="+rev)
	try:
		for x in cek.json()["result"]:
			writer(file, "http://%s" % (x))
		print("  [+] \x1b[1;95m"+rev+"\x1b[1;00m -> \x1b[1;92m"+str(len(cek.json()["result"]))+"\x1b[1;00m site found! ")
	except:
		writer(file, "http://%s" % (rev))
		print("  [+] \x1b[1;95m"+rev+"\x1b[1;00m -> \x1b[1;91m"+file+"\x1b[1;00m domain not found!")

def reverse(rev, file):
	rev = rev.replace("http://","").replace("https://","").split("/")[0]
	cek = r.post("https://askdns.com/search", data={"domip": rev}, headers={"user-agent": choice(agent), "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"}, allow_redirects=True)
	if cek.status_code != 200:
		menunggu()
		reverse(rev,file)
	else:
		cek = par(cek.text, "html.parser")
		if "None Found" in str(cek):
			writer(file, "http://%s" % (rev))
			print("  [URL] \x1b[1;95m"+rev+"\x1b[1;00m -> \x1b[1;91m"+file+"\x1b[1;00m domain not found!")
		else:
			found = []
			try:
				flex = cek.findAll("div", {"class":"flex two"})[-1]
				for yup in flex.find_all("a"):
					writer(file, "http://%s" % (yup.text))
					found.append(yup.text)
				print("\r  [URL] \x1b[1;95m"+rev+"\x1b[1;00m -> \x1b[1;92m"+str(len(found))+"\x1b[1;00m site found! ")
			except:
				print("\r  [URL] \x1b[1;95m"+rev+"\x1b[1;00m -> \x1b[1;92m"+str(len(found))+"\x1b[1;00m site found! ")

def rev(type=None):
	if type is None:
		exit("×: Wrong type\n")
	else:
		if type == "s":
			trg = input("?: ip/domain: ")
			sv  = saved()
			print("")
			reverse(trg, sv)
			print("\n✓: Process done\n")
		if type == "m":
			trg = ceks()
			sv  = saved()
			print("")
			for ya in trg:
				reverse(ya, sv)
			print("\n✓: Process done\n")

def subdo(type=None):
	if type is None:
		exit("×: Wrong type\n")
	else:
		if type == "s":
			trg = input("?: domain: ")
			sv = saved()
			print("")
			subdomain(trg, sv)
			print("\n✓: Process done\n")
		if type == "m":
			trg = ceks()
			sv  = saved()
			print("")
			for ya in trg:
				subdomain(ya, sv)
			print("\n✓: Process done\n")

def start_menu():
	clear()
	print("""
?:: Choose menu:
	1. Single reverse ip/domain
	2. Multi reverse ip/domain
	3. Single subdomain finder
	4. Multi subdomain finder
	""")
	inp = input("?:: choose: ")
	while not inp.isdigit() or inp == "":
		inp = input("?:: choose: ")
	if inp == "1":
		rev(type="s")
	elif inp == "2":
		rev(type="m")
	elif inp == "3":
		subdo(type="s")
	elif inp == "4":
		subdo(type="m")
	else:
		exit("×: wrong choice\n")


if __name__=="__main__":
	start_menu()
