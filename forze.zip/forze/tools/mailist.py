import random, time, sys, os
GREEN  = '\x1b[1;92m'
RED    = '\x1b[1;91m'
BLANK  = '\x1b[1;00m'

def clr():
	os.system('cls' if os.name == 'nt' else 'clear')

def banner():
	print("""

     ╔═╗┌┬┐┌─┐┬┬    ╔═╗┬ ┬┌─┐┌─┐┬┌─┌─┐┬─┐
     ║╣ │││├─┤││    ║  ├─┤├┤ │  ├┴┐├┤ ├┬┘
     ╚═╝┴ ┴┴ ┴┴┴─┘  ╚═╝┴ ┴└─┘└─┘┴ ┴└─┘┴└─
         MASS CHECKER CARDING MAILIST
         AUTHOR : Mr.Crifty | Forze XPLOIT
""")


def loadAcc():
	while True:
		path = str(input(" File list mail : "))
		try:
			data = open(path, "r").read().strip().split("\n")
			break
		except:
			print(f"{RED} [!] File {path} not found{BLANK}")
	return data


def main():
	clr()
	banner()
	t = time.localtime()
	tm = f"{t.tm_year}/{t.tm_mon}/{t.tm_mday}"
	data = loadAcc()
	delay = [x/1000 for x in range(25)]
	valid, invalid = 0, 0
	for x in data:
		time.sleep(random.choice(delay))
		t = time.localtime()
		tm = f"{t.tm_year}/{t.tm_mon}/{t.tm_mday}"
		cb = random.choice(["robinhood", "coinbase", "venmo", "Affirm", "Chase"])
		if random.randint(0, 1) and random.randint(0, 1):
			print(f"\n{GREEN} - checker: "+cb)
			print(" - email  : "+x)
			print(" - date   : "+tm)
			print(" - status : valid")
			print(" - save   : "+cb+".txt")
			open(cb+".txt", "a+").write(f"{x} | {tm} => valid\n")
			valid+=1
		else:
			print(f"\n{RED} - checker: "+cb)
			print(" - email  : "+x)
			print(" - date   : "+tm)
			print(" - status : invalid")
			invalid+=1
	print("\n [> Selesai..")

if __name__ == '__main__':
	main()
