try:
	import requests as r, os, platform, re
	from bs4 import BeautifulSoup as par
	from time import sleep
except Exception as err:
	exit("!!: "+str(err))
from threading import Thread as td
clear = lambda: os.system("clear") if platform.system().lower() == "linux" else os.system("cls")
openFile = lambda file: open(file, "r").read().strip().split("\n")
agent = {"user-agent": "windows"}

def writer(name, content):
	try:
		if content in open(name, "r").read():
			pass
		else:
			open(name, "a+").write(content.strip().replace("\n","")+"\n")
	except FileNotFoundError:
		open(name, "a+").write(content.strip().replace("\n","")+"\n")

def saved():
	while True:
		fln = input("?: save in file: ")
		try:
			openFile(fln)
			ask = input("!: File ini sudah ada\n?: apakah hasilnya mau digabung dengan file ini?\n  >> ya/tidak (Y/T): ")
			if ask in list("Yy"):
				break
			elif ask in list("Tt"):
				continue
			else:
				continue
		except FileNotFoundError:
			break
	return fln

def grabScan(file):
	ok = []
	for x in range(20):
		check = r.get("https://urlscan.io/json/live/", headers=agent).json()
		for rest in check["results"]:
			hasil = rest["task"]["url"]
			ok.append(hasil)
			writer(file, hasil)
			sleep(3)
		print("\r@: get "+str(len(ok))+" domain ", end="")

def grabTops(file):
	check = par(r.get("https://www.topsitessearch.com/domains/").text, "html.parser")
	app = []
	ok = []
	for ahr in check.find_all("a", {"class": "btn btn-secondary"}):
		app.append(ahr.get("href"))
	for x in app:
		while True:
			cuz = par(r.get(x, headers=agent).text, "html.parser")
			cek = re.findall("td.*?<a.*?img.*?>(.*?)<.*?", str(cuz))
			for xx in cek:
				ok.append(xx)
				writer(file, "http://%s" % (xx.strip()))
			print("\r@: get "+str(len(ok))+" domain ", end="")
			if "Next Page »" in str(cuz):
				x = cuz.find("a", string="Next Page »")["href"]
			else:
				break

def grabGreen(file):
	check = par(r.get("https://www.greensiteinfo.com/domain_extensions/").text, "html.parser")
	app = []
	ok = []
	for ahr in check.find_all("td"):
		app.append(ahr.find("a")["href"])
	for x in app:
		while True:
			cuz = par(r.get(x, headers=agent).text, "html.parser")
			cek = re.findall("td.*?<a.*?img.*?>(.*?)<.*?", str(cuz))
			for xx in cek:
				ok.append(xx)
				writer(file, "http://%s" % (xx.strip()))
			print("\r@: get "+str(len(ok))+" domain ", end="")
			if "Next Page »" in str(cuz):
				x = cuz.find("a", string="Next Page »")["href"]
			else:
				break

def main():
	clear()
	print("""
///////////> Grabber Domain <\\\\\\\\\\\\\\\\\\\\\\
""")
	sv = saved()
	grabTops(sv)
	grabGreen(sv)
	grabScan(sv)
	exit("\n✓: Berhasil mengambil seluruh domain\n")



if __name__=="__main__":
	main()
