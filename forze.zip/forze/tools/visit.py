import requests as r, os
from random import choice

ua = open("user-agents.txt","r").read().strip().split("\n")
success = 0
failed = 0

def view(url, agent):
	header = {
		"user-agent": agent,
		"referer": "https://www.google.com",
		"accept-encoding": "gzip",
	}
	try:
		req = r.get(url, headers=header, allow_redirects=True, timeout=10).status_code
		if req == 200:
			return True
		else:
			return False
	except Exception as exc:
		return False

def running():
	global success, failed
	print("""
	\x1b[1;94m╔═╗\x1b[1;97m┬ ┬┌┬┐┌─┐  \x1b[1;94m╦  ╦\x1b[1;97m┬┌─┐┬┌┬┐┌─┐┬─┐
	\x1b[1;94m╠═╣\x1b[1;97m│ │ │ │ │  \x1b[1;94m╚╗╔╝\x1b[1;97m│└─┐│ │ │ │├┬┘
	\x1b[1;94m╩ ╩\x1b[1;97m└─┘ ┴ └─┘   \x1b[1;94m╚╝ \x1b[1;97m┴└─┘┴ ┴ └─┘┴└─
	\x1b[37;1m\033[41m    AUTO VISITOR BY   Mr.Crifty | Forze XPLOIT   \033[00m\n\n\x1b[1;00m""")
	target = input("[+] Target: ")
	jumlah = input("[=] Jumlah: ")
	while jumlah == "" or not jumlah.isdigit():
		jumlah = input("[=] Jumlah: ")
	print("[!] Harap menunggu, sedang proses..\n")
	WoW = 0
	for wow in range(int(jumlah)):
		WoW += 1
		run = view(target, choice(ua))
		if run:
			print(" "*3,str(WoW)+" > \x1b[1;92mBERHASIL MENG-VISIT TARGET WEB\x1b[1;00m")
			success += 1
		else:
			print(" "*3,str(WoW)+" > \x1b[1;91mGAGAL MENG-VISIT TARGET WEB\x1b[1;00m")
			failed += 1
	print("\n[ SELESAI ]")
	print("* url: "+target)
	print("* total visit: \x1b[1;92m"+str(success)+"\x1b[1;00m")
	print("* total gagal: \x1b[1;91m"+str(failed)+"\x1b[1;00m\n")


if __name__=="__main__":
	os.system('cls' if os.name == 'nt' else 'clear')
	running()
