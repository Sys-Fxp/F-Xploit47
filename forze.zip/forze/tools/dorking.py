import requests as req, os, sys, re, time
from urllib.parse import quote, unquote
from bs4 import BeautifulSoup as par
url = "https://search.aol.com/aol/search?q="
show = []

def clear():
    if "win" in sys.platform.lower():
        os.system("cls")
    else:
        os.system("clear")

def start():
    print("""\n
    +=========Dorker@~>Forze - XPLOIT================+
     [01] single dork
     [02] multi dork
     #~> Mr.Crifty
     @~> Forze XPLOIT
                    [https://github.com/kirazetsu]
    +===============================================+
    """)
    pilih = input(">>>root@crifty~# ")
    while pilih == "" or pilih not in ['1','2','01','02']:
        print("> pilih yang betul ngab")
        pilih = input(">>>root@crifty~# ")
    if pilih in ['1','01']:
        single_dork()
    elif pilih in ['2','02']:
        multi_dork()
    else:
         exit(">>>root@crifty~# ")

def dorking(dorks, saved):
        global show
        headers = {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36"}

        ses = req.Session()
        try:
            cek = par(ses.get(dorks, headers=headers).text, "html.parser")
            if "Suggestions:" in str(cek):
                return False
            else:
                for x in cek.find_all("div", {"class": "compTitle options-toggle"}):
                    get_href = x.find("a")["href"]
                    get_href = re.search("RU=(.*?)\/RK.*?", get_href).group(1)
                    try:
                        if unquote(get_href) in open(saved, "r").read():
                           pass
                        else:
                           show.append(unquote(get_href))
                           print("Dorked ==> "+unquote(get_href))
                           open(saved, "a+").write(unquote(get_href)+"\n")
                    except:
                       show.append(unquote(get_href))
                       print("Dorked ==> "+unquote(get_href))
                       open(saved, "a+").write(unquote(get_href)+"\n")
                    #print("\r> "+str(len(show))+" website telah didapatkan... ", end='')

            dorker = cek.find("div", {"class": "compPagination"})
            if "Next" in str(dorker):
                link = dorker.find("a", {"class":"next"})["href"]
                dorking(link, saved)
            else:
                return True
        except:
            return True

def single_dork():
    dork = input(">>>root@dork~> ")
    saved = str(time.asctime(time.localtime(time.time())).replace(" ","_").replace(":", "-")) + ".txt"
    print("> Tunggu sebentar\n> klik ctrl + c untuk berhenti\n")
    dorks = dorking(url+quote(dork), saved)
    if dorks:
        exit("> Maaf tidak ada website yang didapatkan")
    else:
        exit("\n> Berhasil mendapatkan url pencarian\n> result disimpan: " + saved)

def multi_dork():
    dork = input(">>>root@file~> ")
    try:
        nice = open(dork, "r").read().strip().split("\n")
    except FileNotFoundError:
        exit("> file tidak ada ditemukan")
    saved = str(time.asctime(time.localtime(time.time())).replace(" ","_").replace(":", "-")) + ".txt"
    print("> Tunggu sebentar\n> klik ctrl + c untuk berhenti\n")
    for saha in nice:
        print("> pencarian untuk dork ["+saha+"]")
        paste = dorking(url+quote(saha), saved)
        if paste:
            print("> ["+saha+"] gagal didapatkan")
        else:
            pass
        print()
        print("-"*40)
    exit("\n> Berhasil mendapatkan url pencarian\n> result disimpan: " + saved)

if __name__=="__main__":
    clear()
    start()
