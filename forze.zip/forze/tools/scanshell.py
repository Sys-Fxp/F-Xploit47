import os, sys, re
from concurrent.futures import ThreadPoolExecutor as pol
try:
	import requests as r
except ModuleNotFoundError:
	exit("* requests not installed")
clear = lambda: os.system("cls") if "cmd" in sys.platform.lower() else os.system("clear")
validate_url = lambda url: url if re.search("https?://.*?", url) is not None else "http://"+url
error = "[ \x1b[1;91merror\x1b[1;00m ]> "
succs = "[\x1b[1;92msuccess\x1b[1;00m]> "

def start_menu():
	print("""\n
[?] Choose menu:
	1. Single scanner
	2. Multi scanner
	""")
	pil = input("[?] >>> ")
	while pil == "":
		pil = input("[?] >>> ")
	if pil == "1":
		single()
	elif pil == "2":
		multi()
	else:
		exit("[×] Options not available")

def Usepath(url, path):
	global error, succs
	benar, salah = 0, 0
	for list_path in path:
		try:
			reqs = r.get(url+list_path, headers={"user-agent":"chrome"})
			dirs = str(reqs.text)
			if "-rw-r--r" in dirs or "drwxr-xr-x" in dirs or "drwxr-x---" in dirs:
				benar += 1
			elif "type='file'" in dirs or 'type="file"' in dirs:
				benar += 1
			else:
				salah += 1
		except:
			salah += 1
		if benar != 0:
			print("\r"+succs+url+list_path)
			break
		elif salah != 0:
			print(f"\r{error}{url}{list_path[:8]} ", end="")
			continue

def Notpath(url):
	global error, succs
	try:
		reqs = r.get(url, headers={"user-agent":"chrome"})
		dirs = str(reqs.text)
		if "-rw-r--r" in dirs or "drwxr-xr-x" in dirs or "drwxr-x---" in dirs:
			print(succs+url)
		elif "type='file'" in dirs or 'type="file"' in dirs:
			print(succs+url)
		else:
			print(error+url)
	except:
		print(error+url)

def check_path():
	quest = input("[?] Use path custom? [Y/N]: ")
	if quest in list("Yy"):
		name_path = input("[>] File path: ")
		while True:
			try:
				path = open(name_path, "r").read().strip().split("\n")
			except FileNotFoundError:
				print("    -> path no found")
				name_path = input("[>] File path: ")
				continue
			break
		return path
	else:
		return False

def single():
	url = input("\n[?] Shell url: ")
	while url == "":
		url = input("\n[?] Shell url: ")
	validate = validate_url(url)
	use_path = check_path()

	print("")
	with pol(max_workers=5) as sub:
		if use_path:
			sub.submit(Usepath, validate, use_path)
		else:
			sub.submit(Notpath, validate)

def multi():
	name_shell = input("\n[?] Shell path: ")
	while True:
		try:
			path_shell = open(name_shell, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("    -> path no found")
			name_shell = input("\n[?] Shell path: ")
			continue
		break
	use_path = check_path()
	print("")
	with pol(max_workers=10) as sub:
		if use_path:
			for multi in path_shell:
				validate = validate_url(multi)
				sub.submit(Usepath, validate, use_path)
		else:
			for multi in path_shell:
				validate = validate_url(multi)
				sub.submit(Notpath, validate)


if __name__=="__main__":
	clear()
	start_menu()
