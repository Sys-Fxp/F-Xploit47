from concurrent.futures import ThreadPoolExecutor as kers
import requests as r, os, sys, re
from os.path import exists as adagak
clear = lambda: os.system("cls") if "cmd" in sys.platform.lower() else os.system("clear")

def saved():
	files = input("[=] Save result: ")
	while adagak(files):
		print("[=] File tersebut sudah ada")
		yt = input("[?] Ingin menimpa hasil? [Y/T]: ")
		if yt in list("Yy"):
			return files
		elif yt in list("Tt"):
			files = input("[=] Save result: ")
			continue
		else:
			files = input("[=] Save result: ")
			continue
	return files

def ceks():
	fileip = input("[?] File target: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("[!] File not found")
			fileip = input("[?] File target: ")
			continue
		break
	return check

def runner(target, save):
	list_path = ['/fileman/dev.html', '/fileman/dev.php', '/filemanager/dialog.php', '/filemanager/dialog.html', '/file/man.html', '/fileman/index.html', '/fileman/index.php']
	target = re.findall("(https?://.*?/)", str(target))[0]
	salah, benar = 0, 0

	for lstc in list_path:
		try:
			mantan = r.get(target+lstc, headers={"user-agent": "chrome"})
			if 'type="file"' in str(mantan.text.lower()) and "upload" in str(mantan.text.lower()) and mantan.status_code == 200:
				with open(save, "a+") as wr:
					wr.write(target+lstc+"\n")
				benar += 1
			else:
				salah += 1
		except:
			salah += 1
		if benar != 0:
			print("\r   \x1b[1;92m"+target+lstc+" -> vuln\x1b[1;00m")
			break
		if salah != 1:
			print("\r   \x1b[1;91m"+target+lstc+" -> not vuln\x1b[1;00m ", end="")
			continue


def start_menu():
	print("""
	(Responsive File Manager Checker)

[!] Note: url harus berawal http atau https dan ditutup dengan slash
    contoh: http://domain/ | https://domain/

[?] Choose menu:
	1. Single rfm checker
	2. Multi rfm checker
	""")
	pil = input("[?] Choose: ")
	while pil == "":
		print("[>] Not found")
		pil = input("[?] Choose: ")
	if pil == "1":
		single()
	elif pil == "2":
		multi()
	else:
		exit("[?] Not found\n")

def single():
	ipd = input("[?] Input url target: ")
	while ipd == "":
		ipd = input("[?] Input url target: ")
	name_save = saved()
	print("[!] Wait in process\n\n")
	runner(ipd, name_save)
	exit("\n\n[✓] Process Done.. enjoy\n")

def multi():
	name_multi = ceks()
	file_save = saved()
	print("[!] Wait in process\n\n")

	with kers(max_workers=10) as sub:
		for cont in name_multi:
			sub.submit(runner, cont, file_save)
	exit("\n\n[✓] Process Done.. enjoy\n")

if __name__=="__main__":
	clear()
	start_menu()
