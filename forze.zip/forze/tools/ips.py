import socket, re, os

os.system("clear")
print("""

_____________   ____
\_   ___ \   \ /   /
/    \  \/\   Y   /	Convert Domain to IP
\     \____\     /      ————————————————————
 \______  / \___/   Author: Mr.Crifty | Forze XPLOIT
        \/

""")
while True:
	try:
		xe = input("> File: ")
		op = open(xe, "r").read().strip()
		break
	except FileNotFoundError:
		print("> File tidak ditemukan")
		continue
sv = input("? Save output: ")
domain = re.findall("(https?://.*?)/", op)
if domain == []:
	exit("! Pastikan file tersebut terisi dengan url")
print("-"*40)
for url in domain:
	repl = url.replace("https://","").replace("http://","")
	try:
		gets = socket.gethostbyname(repl)
		print("=> \x1b[1;92m"+repl+"\x1b[1;00m >\x1b[1;92m "+gets+"\x1b[1;00m")
		save = repl+"|"+gets
		try:
			if save not in open(sv, "r").read():
				open(sv, "a+").write(save+"\n")
		except:
			open(sv, "a+").write(save+"\n")
	except:
		print("=> \x1b[1;93m"+repl+"\x1b[1;00m > \x1b[1;91mnot found\x1b[1;00m")
print("-"*40, "\n")
