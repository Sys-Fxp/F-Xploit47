try:
	import cloudscraper, re, os
except ModuleNotFoundError:
	exit("! Module not installed")

scraper = cloudscraper.create_scraper()
clear = lambda: os.system('cls' if os.name == 'nt' else 'clear')

def check(url):
	if re.search("[.]", url[-8:]) is not None:
		return False
	else:
		xget = scraper.get(url).text
		if "Index of" in str(xget):
			return True
		else:
			return False

def running(url):
	try:
		os.mkdir("result")
	except:
		pass
	ses = scraper.get(url).text
	arg = re.findall("\<a href=\"(.*?)\">.*?\.txt<\/a>", str(ses))
	for ling in arg:
		xcon = scraper.get(url+"/"+ling).content
		with open("result/"+ling, "wb") as sv:
			sv.write(xcon)
	return str(len(arg))


if __name__=="__main__":
	clear()
	print("""
    .===. (
    |   |  )
    |   | (
    |   | )     ╔╦╗┬┬─┐  ┌─┐┌─┐┌─┐┌┐┌┌┐┌┌─┐┬─┐
    |   \*/      ║║│├┬┘  └─┐│  ├─┤││││││├┤ ├┬┘
  ,'    //.     ═╩╝┴┴└─  └─┘└─┘┴ ┴┘└┘┘└┘└─┘┴└─
 :~~~~~//~~;	   Get Files From Dir + Dump
  `.  // .' Mr.Crifty
  `-------'
     Forze XPLOIT
	""")
	name_url = input("\n> File: ")
	try:
		xy = open(name_url, "r").read().strip().split("\n")
	except:
		exit("! file does not exist")

	process = 0
	for urlin in xy:
		process += 1
		if check(urlin):
			print("\x1b[1;92m["+str(process)+"] success get "+running(urlin)+" files\x1b[1;00m")
		else:
			print("\x1b[1;91m["+str(process)+"] failed get files\x1b[1;00m")
	print("\n[✓] Done, all files are stored in the 'result' folder\n")
