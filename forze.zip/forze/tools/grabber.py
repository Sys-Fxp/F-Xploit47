#!/usr/bin/python
# -*- coding: utf-8 -*-
from pprint import pprint
from datetime import datetime
import requests, re, platform, random
from os import system
from sys import platform as pl
from bs4 import BeautifulSoup as par

purple = '\033[95m'
blue = '\033[94m'
cyan = '\033[96m'
green = '\033[92m'
yellow = '\033[93m'
red = '\033[91m'
end = '\033[0m'
bold = '\033[1m'
u = '\033[4m'

if pl == 'win32':
    system('color')

url = 'https://com.all-url.info/{}/{}/'
user_agent = 'Mozilla/5.0 (platform; rv:geckoversion) Gecko/geckotrail Firefox/firefoxversion'
ubuntu_color = random.choice([yellow, cyan, end])
print(f'''{red}
            .-/+oossssoo+/-.  
        `:+ssssssssssssssssss+:`     
      -+ssssssssssssssssssyyssss+-       
    .ossssssssssssssssss{ubuntu_color}dMMMNy{red}sssso.       
   /sssssssssss{ubuntu_color}hdmmNNmmyNMMMMh{red}ssssss/    
  +sssssssss{ubuntu_color}hm{red}yd{ubuntu_color}MMMMMMMNddddy{red}ssssssss+
 /ssssssss{ubuntu_color}hNMMM{red}yh{ubuntu_color}hyyyyhmNMMMNh{red}ssssssss/   
.ssssssssd{ubuntu_color}MMMNh{red}ssssssssss{ubuntu_color}hNMMMd{red}ssssssss.  
+ssss{ubuntu_color}hhhyNMMNy{red}ssssssssssss{ubuntu_color}yNMMMy{red}sssssss+  {green}  Mr.Crifty - Forze-XPLOIT{red}
oss{ubuntu_color}yNMMMNyMMh{red}ssssssssssssss{ubuntu_color}hmmmh{red}ssssssso  {green}  Priv8 Mass Grabber V.2 New Api{red}
oss{ubuntu_color}yNMMMNyMMh{red}sssssssssssssshmmmh{red}ssssssso  {green}  Server: {platform.platform()} {red}
+ssss{ubuntu_color}hhhyNMMNy{red}ssssssssssssy{ubuntu_color}NMMM{red}ysssssss+  {green}  Date: {datetime.today().strftime('%Y-%m-%d %H:%M:%S')} {red}
.ssssssss{ubuntu_color}dMMMNh{red}ssssssssss{ubuntu_color}hNMMMd{red}ssssssss.    
 /ssssssss{ubuntu_color}hNMMM{red}yh{ubuntu_color}hyyyyh{ubuntu_color}dNMMMNh{red}ssssssss/
  +sssssssss{ubuntu_color}dm{red}yd{ubuntu_color}MMMMMMMMddddy{red}ssssssss+
   /sssssssssss{ubuntu_color}hdmNNNNmyNMMMMh{red}ssssss/
    .ossssssssssssssssss{ubuntu_color}dMMMNy{red}sssso.
      -+sssssssssssssssss{ubuntu_color}yyy{red}ssss+-
        `:+ssssssssssssssssss+:`
            .-/+oossssoo+/-. {end}\n''')


domain = int(input('Pilih angka (1-10000): '))
page = int(input('Page: '))
to = int(input('To Page: '))
tahun = input("Tahun: ")
bulan = input("Bulan: ")
tgls = input("Sampai tanggal: ")
save_filename = 'crifty.txt'
print('\n')
print('results are saved in '+save_filename)
num = 0
for i in range(page, to+1):
    try:
        req = requests.get(url.format(domain, i), headers={'User-Agent': user_agent}, timeout=50)
        domains = re.findall('<a href=https://com.all-url.info/com/([^>]*)/>', req.text)
        for yz in domains:
                num += 1
                print("\r[!] Found "+str(num)+" Domain ", end="")
                with open(save_filename, 'a') as sv:
                     sv.write(yz.strip().replace("\n","") + "\n")
    except:
        print('\r[-] Error di angka {}'.format(i))
print("")
for x in range(1, int(tgls)+1):
    if x < 10:
    	qq = "0"+str(x)
    else:
        qq = x
    query = bulan+"-"+str(qq)+"-"+tahun
    try:
       req = requests.get("https://www.desktopcatcher.com/wp-content/plugins/domaingrab/download.php?date="+query).text
       if "." in req:
            finds = req.strip().split("\n")
            icikiwir = 0
            for fn in finds:
                    icikiwir += 1
                    print("\r[+] Found {} Domain [{}]".format(str(icikiwir), query), end="")
                    with open(save_filename, 'a') as sv:
                         sv.write(fn.strip().replace("\n","") + "\n")
       else:
            print('\r[-] Error, domain not found [{}]'.format(query))
    except:
        print('\r[-] Error, domain not found [{}]'.format(query))

print("")
nek = 0
take = par(requests.get("https://whoisdatacenter.com/free-database", headers={"user-agent":"chrome"}).text, "html.parser")
for td in take.find_all("td", {"class":"first domain_name"}):
    nek += 1
    gets = td.find("a").text
    print("\r[•] Collect "+str(nek)+" Domain.. ", end="")
    with open(save_filename, "a") as sev:
         sev.write(gets+"\n")
print("")
def addbros():
  cek = par(requests.get("https://www.iana.org/domains/root/db", headers={"user-agent":"chrome"}).text, "html.parser")
  td = 0
  for x in cek.find_all("span", {"class": "domain tld"}):
    gets = x.find("a")["href"];
    putar = requests.get("https://www.iana.org"+gets, headers={"user-agent":"chrome"}).text 
    egex = re.search("registration services:.*?href=\"(.*?)\".*", str(putar))
    if egex is not None:
      td += 1
      print("\r[•] Collect "+str(td)+" Domain.. ", end="")
      with open(save_filename, "a") as sev:
         sev.write(egex.group(1)+"\n")
    else:
      continue
addbros()
print("")

def IndexOf():
  net = 0
  try:
    coks = requests.get("https://hole.cert.pl/domains/domains.csv").text 
    for col in coks.split("\n"):
      yeah = re.findall("\d+\s+(.*?)\s+", col)
      if yeah == []:
        pass
      else:
        net += 1
        with open(save_filename, "a") as sev:
         sev.write("".join(yeah)+"\n")
        print("\r[•] process (1) Collect "+str(net)+" Domain.. ", end="")
  except:
    pass


  try:
    coks = requests.get("https://hole.cert.pl/domains/domains.json").json()
    for x in coks:
      net += 1
      with open(save_filename, "a") as sev:
        sev.write(x["DomainAddress"]+"\n")
      print("\r[•] process (2) Collect "+str(net)+" Domain.. ", end="")
  except:
    pass

  try:
    coks = requests.get("https://hole.cert.pl/domains/domains.txt").text.split("\n")
    for x in coks:
      net += 1
      with open(save_filename, "a") as sev:
        sev.write(x+"\n")
      print("\r[•] process (3) Collect "+str(net)+" Domain.. ", end="")
  except:
    pass

  try:
    coks = requests.get("https://hole.cert.pl/domains/domains.xml").text 
    gex = re.findall("<AdresDomeny>(.*?)</AdresDomeny>", coks)
    for x in gex:
      net += 1
      with open(save_filename, "a") as sev:
        sev.write(x+"\n")
      print("\r[•] process (4) Collect "+str(net)+" Domain.. ", end="")
  except:
    pass

  try:
    coks = requests.get("https://hole.cert.pl/domains/domains_adblock.txt").text 
    gex = re.findall("\|\|(.*)\^\$all", coks)
    for x in gex:
      net += 1
      with open(save_filename, "a") as sev:
        sev.write(x+"\n")
      print("\r[•] process (5) Collect "+str(net)+" Domain.. ", end="")
  except:
    pass

  try:
    coks = requests.get("https://hole.cert.pl/domains/domains_hosts.txt").text 
    gex = re.findall(".*\s(.*)", coks)
    for x in gex:
      net += 1
      with open(save_filename, "a") as sev:
        sev.write(x+"\n")
      print("\r[•] process (6) Collect "+str(net)+" Domain.. ", end="")
  except:
    pass

  try:
    coks = requests.get("https://hole.cert.pl/domains/domains_mikrotik.rsc").text 
    gex = re.findall("name=\"(.*?)\"\s", coks)
    for x in gex:
      net += 1
      with open(save_filename, "a") as sev:
        sev.write(x+"\n")
      print("\r[•] process (7) Collect "+str(net)+" Domain.. ", end="")
  except:
    pass
IndexOf()


print("\n[✓] Done proses\n")
