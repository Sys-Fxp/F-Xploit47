import requests as r, os, sys, re
from os.path import exists as adagak
from bs4 import BeautifulSoup as par

clear = lambda: os.system("cls") if "cmd" in sys.platform.lower() else os.system("clear")

def saved():
	files = input("[=] Save result: ")
	while adagak(files):
		print("[=] File tersebut sudah ada")
		yt = input("[?] Ingin menimpa hasil? [Y/T]: ")
		if yt in list("Yy"):
			return files
		elif yt in list("Tt"):
			files = input("[=] Save result: ")
			continue
		else:
			files = input("[=] Save result: ")
			continue
	return files

def ceks():
	fileip = input("[?] File target: ")
	while True:
		try:
			check = open(fileip, "r").read().strip().split("\n")
		except FileNotFoundError:
			print("[!] File not found")
			fileip = input("[?] File target: ")
			continue
		break
	return check

def runner(media, save):
	cek = par(r.post("https://askdns.com/search", data={"domip": media}, headers={"user-agent": "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36", "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"}, allow_redirects=True).text, "html.parser")
	if "None Found" in str(cek):
		print("[•] ("+media+") No found result")
	else:
		flex = cek.findAll("div", {"class":"flex two"})[-1]

		#-> get ip address
		try:
			get_ip = re.findall("/ip/(\d+.\d+.\d+.\d+)\".*", str(cek))[0]
			get_upt = re.findall("Last\sUpdated:.*?\n.*?div>(\d+-\d+-\d+).*?", str(cek))[0]
			print("\t [•] IP ADDRESS : "+get_ip)
			print("\t [•] LAST UPDATE: "+get_upt)
		except:
			pass

		gets = 0
		for yup in flex.find_all("a"):
			gets += 1
			with open(save, "a+") as sub:
				sub.write(yup.text+"\n")
		print("\t [•] Success Get "+str(gets)+" result from "+media)
		print("\t", "-"*50)


def start_menu():
	print("""
[?] Choose menu:
	1. Single reverse
	2. Multi reverse
	""")
	pil = input("[?] Choose: ")
	while pil == "":
		print("[>] Not found")
		pil = input("[?] Choose: ")
	if pil == "1":
		single()
	elif pil == "2":
		multi()
	else:
		exit("[?] Not found\n")


def single():
	ipd = input("\n[?] Input IP/DOMAIN: ")
	while ipd == "":
		ipd = input("\n[?] Input IP/DOMAIN: ")
	name_save = saved()
	print("[!] Wait in process\n\n")
	runner(ipd, name_save)
	exit("\n[✓] Process Done.. enjoy\n")

def multi():
	name_multi = ceks()
	file_save = saved()
	print("[!] Wait in process\n\n")

	for cont in name_multi:
		runner(cont, file_save)
	exit("\n[✓] Process Done.. enjoy\n")

if __name__=="__main__":
	clear()
	start_menu()
